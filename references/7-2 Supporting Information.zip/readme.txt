1_XPS: One .xlsx file with a page for each plot. Collumn A is the binding energy in eV, collumn B is the counts per second. All other collumns are headed with correct labels.
2_raman: One file for each phase of both materials. Two columns - raman shift (cm2^-2) vs intensity (arbitary).
3_ellipsometry: Six text files, one for each material shown in Figure 3, containing the full data sets. Three columns, wavelength (nm) : n : k
4_pulse_maps: Four files, each is an NxM array of pixel values from Figure 4.
5_SbSe_burn_in: Two text files. "SbSe_burnin_a.txt" is the data for fig. 5a, single column of mean reflection change (%) for each phase change cycle. "SbSe_burnin_b.txt" is the data for fig 5b, single column of reflection (%) for phase change cycles 2495 to 2505, 36 data points per cycle  
6_SWG_losses: Single file, with the mean and standard deviation for each length of both phases of SbS and SbSe. 
S1_ellipsometry: Single file with all ellipsometer traces for different anneal temperatures of SbS and SbSe.
S2_SbS_burn_in: Single file, one collumn of average reflection change per phase switching cycle of SbS.


READ ME File For 'Dataset title'

Dataset DOI: 10.5258/SOTON/D1247

ReadMe Author: Otto Muskens, University of Southampton ORCID ID 0000-0003-0693-5504	

This dataset supports the publication:
AUTHORS:Matthew Delaney  Ioannis Zeimpekis  Daniel Lawson  Daniel W. Hewak  Otto L. Muskens
TITLE:A New Family of Ultralow Loss Reversible Phase‐Change Materials for Photonic Integrated Circuits: Sb2S3 and Sb2Se3
JOURNAL: Advance Functional Materials
PAPER DOI:https://doi.org/10.1002/adfm.202002447

One folder for each figure (excluding Fig.2 as it is optical images) in the main text and supporting information. 

The figures are as follows:
Fig. 1  X-ray photoelectron spectroscopy of amorphous Sb2S3 and Sb2Se3. XPS: One .xlsx file with a page for each plot. Column A is the binding energy in eV, column B is the counts per second. All other columns are headed with correct labels.
Fig. 2  DIC optical images of silicon chips with thin films.
Fig. 3  Raman spectroscopy for amorphous and crystalline thin films of Sb2S3 and Sb2Se3 before and after laser annealing.raman: One file for each phase of both materials. Two columns - raman shift (cm2^-2) vs intensity (arbitary)
Fig. 4  Ellipsometry of Sb2S3, Sb2Se3, GST.ellipsometry: Six text files, one for each material shown in Figure 3, containing the full data sets. Three columns, wavelength (nm) : n : k
Fig. 5  2D pulse maps for amorphising and crystallising Sb2S3 and Sb2Se3. pulse_maps: Four files, each is an NxM array of pixel values from Figure 4.
Fig. 6  Burn in cycle for Sb2Se3. SbSe_burn_in: Two text files. "SbSe_burnin_a.txt" is the data for fig. 5a, single column of mean reflection change (%) for each phase change cycle. "SbSe_burnin_b.txt" is the data for fig 5b, single column of reflection (%) for phase change cycles 2495 to 2505, 36 data points per cycle  
Fig. 7  Straight waveguide losses for phase change material claddings.SWG_losses: Single file, with the mean and standard deviation for each length of both phases of SbS and SbSe.
Fig. S1 Temperature dependent ellipsometry for Sb2S3 and Sb2Se3. Single file with all ellipsometer traces for different anneal temperatures of SbS and SbSe.
Fig. S2 Burn in cycle for Sb2Se3. Single file, one column of average reflection change per phase switching cycle of SbS.


Date of data collection: 
Fig. 1  
Fig. 2  28/06/2019
Fig. 3  07/06/2019
Fig. 4  12/06/2019
Fig. 5  02/12/2019
Fig. 6  27/01/2020
Fig. 7  22/01/2020
Fig. S1 12/06/2019
Fig. S2 12/10/2019

Licence: CC BY http://creativecommons.org/licenses/by/4.0/

Information about geographic location of data collection: All data collected at Highfield Campus, Southampton

Related projects:
This work was supported by the Engineering and Physical Sciences Research Council (EPSRC) (EP/L021129/1, EP/M015130/1, EP/M009122/1, and EP/G060363/1).


Date that the file was created: July, 2020